# Ovládací software pro nezávislé ovládání pěti pneumatických svalů v robotické struktuře

Aplikace je spustitelná pouze na soustavě.

Pro spuštění ve vývojářském módu využijte soubor `main.py`  
Ostatní soubory nejsou vytvořeny pro samostatné spuštění.